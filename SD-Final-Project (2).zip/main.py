# Reptile Plushie Shop
# Gabriel Bumgardner
# This program will open two windows, one that will show up and say "Welcome to the Reptile Plushie Shop!" and the other will show up and display multiple buttons that will first allow the user to select how many plushies they want and an exit button that will allow the user to exit the program.  


from tkinter import *

from PIL import ImageTk, Image



def main():
  """This function defines the 'mainline logic' for our program."""
  # Create a window with the title "Welcome to the Reptile Plushie Shop!"
  window1 = Tk() # Creates a window
  window1.title("Welcome to the plsuhie shop!") 
  window1.geometry("500x500") 
  window1.configure(bg="light blue") 
  welcome = Label(window1, text="Welcome to the plsuhie shop!", bg="light blue", fg="red", font=("Arial", 15)) # Creates a label that will display the text "Welcome to the plsuhie shop!"
  welcome.place(x=150, y=50) # Places the label on the window

  # Creates an image object for the window
  img = Image.open('Welcome.jpg') # Opens the image file for the window
  img = img.resize((200, 200)) # Resizes the image
  img = ImageTk.PhotoImage(img) # Makes the image a photo image
  panel = Label(window1, image = img) # Creates a label that will display the image in the window
  panel.place(x=200, y=120) 

  # Creates a loop that will run until the user closes the window
  window1.mainloop()

  # Creates a root window with the title "Welcome to the Reptile Plushie Shop!"
  root = Tk() # Creates a root window 
  root.title("Welcome to the plsuhie shop!") # Sets the title of the window
  root.geometry("500x500")
  root.configure(bg="light blue")
  
  # Creates an image object for the root window
  img = Image.open('PlushieConstruction.jpg') # Opens the image file for the root window
  img = img.resize((100, 100)) # Resizes the image
  img = ImageTk.PhotoImage(img) # Makes the image a photo image
  panel = Label(root, image = img) # Creates a label that will display the image in the root window
  panel.place(x=0, y=0)

    
  def exit():
    """This function will allow the user to exit the program."""
    root.destroy()

  # Creates a button that will allow the user to exit the program
  myButton = Button(root, text="Exit", command=exit).pack() # Creates a button that will allow the user to exit the program

  def plushieClass():
    """This function will allow the user to select how many plushies they want"""
    # Creates a list of choices for the user to select from for the number of plushies they want
    plushieTypeClass = Listbox(root) # Creates a listbox that will allow the user to select how many plushies they want
    plushieTypeClass.insert(1, "1") 
    plushieTypeClass.insert(2, "2")
    plushieTypeClass.insert(3, "3")
    plushieTypeClass.insert(4, "4")
    plushieTypeClass.insert(5, "5")

    # Prints result for the user to see with the input they entered
    print("You have ordered", input(""),"plushies")

    
    def plushieChoice():
      """This function allows the user to select the number of plushies from the listbox"""
      # This variable represents the number of plushies the user wants
      plushieChoice = plushieTypeClass.get(ACTIVE) # Gets the number of plushies the user wants
      
      # Prints result for the user to see
      print(plushieChoice)
      
      # The following if statements will print the number of plushies the user wants
      if plushieTypeClass.get(1) == "1": 
        print("1 Plushie")
      elif plushieTypeClass.get(2) == "2":
        print("2 Plushie")
      elif plushieTypeClass.get(3) == "3":
        print("3 Plushie")
      elif plushieTypeClass.get(4) == "4":
        print("4 Plushie")
      elif plushieTypeClass.get(5) == "5":
        print("5 Plushie")
      else:
        print("No plushie selected")
  
  # Creates and labels a button that will allow the user to select how many plushies they want and a seprate button that will allow the user to enter their choice of how many plushies they want
  plushieChoice = StringVar() # Creates a string variable that will allow the user to select the number of plushies they want
  plushieChoice.set("Number of Plushies") 
  plushieLabel = Label(root, text="Plushie Amount", bg="light blue", fg="red") # Creates a label that will display the text "Plushie Amount"
  plushieLabel.place(x=220, y=50)
  plushieClassList = ["1", "2", "3", "4", "5"] # Lets the user select the number of plushies they want 
  plushieChoiceMenu = OptionMenu(root, plushieChoice, *plushieClassList) # Creates an option menu that will allow the user to select the number of plushies they want
  plushieChoiceMenu.place(x=185, y=75)
  plushieButton = Button(root, text="Select", command=plushieClass) # Creates a button that will allow the user to select the number of plushies they want
  plushieButton.place(x=220, y=125)

  def reptilePlushie(): 
    """This function allows the user to select the reptile plushie they want"""
    # Creates a list of choices for the user to select from for the reptile plushie they want
    reptileList = Listbox(root) # Creates a listbox that will allow the user to select type of reptile plushie they want
    reptileList.insert(1, "Snake plushie")
    reptileList.insert(2, "Lizard plushie")
    reptileList.insert(3, "Alligator plushie")
    reptileList.insert(4, "Turtle plushie")
    reptileList.insert(5, "Frog plushie")

    # Prints result for the user to see with the input they entered
    print("You have selected the", input(""), "plushie!")

    def repChoice():
      """This function allows the user to select the reptile plushie from the 'What Type of Plushie?' listbox"""
      reptileChoice = reptileList.get(ACTIVE) # Gets the type of reptile plushie the user wants
      
      # Prints result for the user to see
      print(reptileChoice)

      # The following if statements will print the type of reptile plushie the user wants
      if reptileList.get(0) == "Snake plushies": 
        print("Snake plushie")
      elif reptileList.get(1) == "Lizard plushies":
        print("Lizard plushie")
      elif reptileList.get(2) == "Alligator plushies":
        print("Alligator plushie")
      elif reptileList.get(3) == "Turtle plushie":
        print("Turtle plushie")
      elif reptileList.get(4) == "Frog plushie":
        print("Frog plushie")
      else:
        print("No plushie selected")

  # Creates a button that will allow the user to select the type reptile plushie they want and a seprate button that will allow the user to enter their choice of what type reptile plushie they want
  reptileChoice = StringVar() # Creates a string variable that will allow the user to select the type of reptile plushie they want
  reptileChoice.set("What Type of Plushie?")
  reptileLabel = Label(root, text="Reptile List", bg="light blue", fg="red") # Creates a label that will display the text "Reptile List" for the user to select the type of reptile plushie they want
  reptileLabel.place(x=225, y=165)
  reptileList = ["Snake", "Lizard", "Alligator", "Turtle", "Frog"] # Lets the user select the type of reptile plushie they want
  reptileChoiceMenu = OptionMenu(root, reptileChoice, *reptileList) # Creates an option menu that will allow the user to select the type of reptile plushie they want
  reptileChoiceMenu.place(x=170, y=185)
  reptileButton = Button(root, text="Select", command=reptilePlushie) # Creates a button that will allow the user to select the type of reptile plushie they want
  reptileButton.place(x=220, y=235)

  # Creates a loop for the root window that will run until the user presses the exit button and closes the window
  root.mainloop()

# This code will run the main function in the program
main()

# This will pring the following text to the console after pressing the exit button
print("Thank you for shopping with us!")